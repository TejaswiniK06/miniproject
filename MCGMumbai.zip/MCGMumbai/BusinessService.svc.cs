﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MCGMumbai
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class BusinessService : IBusinessService
    {
        SqlConnection cn = null;                
        SqlCommand cmd = null;
        SqlDataReader dr = null;


       

        public void Add(Business business)      //Add method is implemented
        {

            try
            {
                                       //sql connection 
                cn = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");

                cmd = new SqlCommand("[46008420].[SP_Business]", cn);      //SP_Business stored procedure 

                cmd.CommandType = CommandType.StoredProcedure;
               
                cmd.Parameters.AddWithValue("@FirmName", business.FirmName);
                cmd.Parameters.AddWithValue("@ActivityNature", business.ActivityNature);
                cmd.Parameters.AddWithValue("@FirmAddress",business.FirmAddress);
                cmd.Parameters.AddWithValue("@OwnerName", business.OwnerName);
                cmd.Parameters.AddWithValue("@MobileNo", business.MobileNo);
                cmd.Parameters.AddWithValue("@EmailAddress", business.EmailAddress);
               

                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
    }
}
