﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MCGMumbai
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IBusinessService
    {
        [OperationContract]
        void Add(Business business);              
       
    }
           
    public class Business
    {
        [DataMember]
        public int BusinessId { get; set; }

        [DataMember]
        public string FirmName { get; set; }
                
        [DataMember]
        public string ActivityNature { get; set; }

        [DataMember]
        public string FirmAddress { get; set; }

        [DataMember]
        public string OwnerName { get; set; }
        [DataMember]
        public string MobileNo { get; set; }

        [DataMember]
        public string EmailAddress { get; set; }






    }
}
