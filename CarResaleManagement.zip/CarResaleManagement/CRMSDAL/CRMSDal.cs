﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using CRMSEntities;
using CRMSExceptions;

namespace CRMSDAL
{
    public class CRMSDal
    {
        public static bool SellerRegistrationDetails(SellerEntity seller)
        {
            bool sellerRegistered = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008057].usp_SellerRegistration", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //SqlParameter objSqlParam_Id = new SqlParameter("@Id", seller.Id);
                SqlParameter objSqlParam_Username = new SqlParameter("@Username", seller.UserName);
                SqlParameter objSqlParam_Password = new SqlParameter("@Password", seller.PassWord);
                SqlParameter objSqlParam_Fullname = new SqlParameter("@Fullname", seller.FullName);
                SqlParameter objSqlParam_Email = new SqlParameter("@Email", seller.Email);
                SqlParameter objSqlParam_Mobile = new SqlParameter("@Mobile", seller.Mobile);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", seller.Address);
                //objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Username);
                objCom.Parameters.Add(objSqlParam_Password);
                objCom.Parameters.Add(objSqlParam_Fullname);
                objCom.Parameters.Add(objSqlParam_Email);
                objCom.Parameters.Add(objSqlParam_Mobile);
                objCom.Parameters.Add(objSqlParam_Address);
                objCon.Open();
                objCom.ExecuteNonQuery();
                sellerRegistered = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CRMSException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return sellerRegistered;

        }



        public bool AddCarbySeller(CarEntity Car, InterestRequests requests)
        {
            bool addedCar = false;
            SqlConnection connection;
            //SqlDataAdapter adap;
            //CarEntity car = null;
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();

            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("[46008057].usp_AddcarbySeller", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Title", Car.Title);
                cmd.Parameters.AddWithValue("@Description", Car.Description);
                cmd.Parameters.AddWithValue("@Model", Car.Model);
                cmd.Parameters.AddWithValue("@Brand", Car.Brand);
                cmd.Parameters.AddWithValue("@RCStatus", Car.RCStatus);
                cmd.Parameters.AddWithValue("@PurchaseYear", Car.PurchaseYear);
                cmd.Parameters.AddWithValue("@sellerId", Car.SellerId);
                cmd.Parameters.AddWithValue("@ExpectedPrice", Car.ExpectedPrice);
                cmd.Parameters.AddWithValue("@AddedDate ", Car.AddedDate);
                cmd.Parameters.AddWithValue("@Status ", requests.Status);

                cmd.Connection = connection;
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    addedCar = true;
            }
            catch (SqlException e)
            {
                throw new CRMSException(e.Message);
            }
            finally
            {
                connection.Close();
            }

            return addedCar;

        }


        public bool RemoveCarBySeller(int Id, InterestRequests ir)
        {
            bool isDeleted = false;
            SqlConnection connection;

            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand cmd = new SqlCommand();


            try
            {

                connection.Open();
                cmd.Connection = connection;
                cmd = new SqlCommand("[46008057].usp_RemovecarbySeller", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", Id);
                cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 50)).Value = ir.Status;
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    isDeleted = true;
            }
            catch (SqlException ex)
            {
                throw new CRMSException(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }


        public bool UpdateCarBySeller(CarEntity Car)
        {
            bool isUpdated = false;

            SqlConnection connection;
            SqlDataAdapter adap;

            connection = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("[46008057].usp_UpdatecarbySeller", connection);

                cmd.Parameters.AddWithValue("@Id", 7);
                cmd.Parameters.AddWithValue("@Title", Car.Title);
                cmd.Parameters.AddWithValue("@Description", Car.Description);
                cmd.Parameters.AddWithValue("@Model", Car.Model);
                cmd.Parameters.AddWithValue("@Brand", Car.Brand);
                cmd.Parameters.AddWithValue("@RCStatus", Car.RCStatus);
                cmd.Parameters.AddWithValue("@PurchaseYear", Car.PurchaseYear);
                cmd.Parameters.AddWithValue("@SellerId", Car.SellerId);
                cmd.Parameters.AddWithValue("@ExpectedPrice", Car.ExpectedPrice);
                cmd.Parameters.AddWithValue("@AddedDate", Car.AddedDate);

                cmd.Connection = connection;
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    isUpdated = true;
            }
            catch (SqlException e)
            {
                throw new CRMSException(e.Message);
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }


        public DataTable SearchByIdDal(int Id)
        {
            DataTable dtw = null;
            SqlConnection objCon;
            SqlDataAdapter adap;
            // MainCar car = null;
            objCon = new SqlConnection(
             ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();
            try
            {
                objCon.Open();
                objCom.Connection = objCon;
                objCom.CommandText = "[46008057].usp_SearchcarBySeller";
                objCom.CommandType = CommandType.StoredProcedure;

                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;

                dtw = new DataTable();

                objCom.Parameters.AddWithValue("@Id", Id);
                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);
            }
            catch (SqlException objSqlEx)
            {
                throw new CRMSException(objSqlEx.Message);
            }
            return dtw;
        }


        public DataTable SearchCarModelbyBuyer(String Model, String Brand)
        {
            DataTable dtw = null;
            SqlConnection objCon;
            SqlDataAdapter adap;
            //CarEntity car = null;
            objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();
            try
            {
                objCon.Open();
                objCom.CommandText = " [46008057].usp_SearchcarmodelbyBuyer";
                objCom.CommandType = CommandType.StoredProcedure;
                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;
                objCom.Connection = objCon;
                dtw = new DataTable();
                objCom.Parameters.AddWithValue("@Model", Model);
                objCom.Parameters.AddWithValue("@Brand", Brand);
                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);
            }
            catch (SqlException objSqlEx)
            {
                throw new CRMSException(objSqlEx.Message);
            }
            return dtw;
        }

        public DataTable DisplayAll()
        {
            DataTable dtw = null;
            SqlConnection objCon;
            SqlDataAdapter adap;
            objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();

            try
            {
                objCon.Open();
                objCom.CommandText = "[46008057].usp_displayCars";
                objCom.CommandType = CommandType.StoredProcedure;

                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;
                objCom.Connection = objCon;
                dtw = new DataTable();
                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);
            }
            catch (SqlException objSqlEx)
            {
                throw new CRMSException(objSqlEx.Message);
            }
            return dtw;
        }


        public static bool BuyerRegistrationDetails(BuyerEntity buyer)
        {
            bool buyerRegistered = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008057].usp_BuyerRegistration", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_Id = new SqlParameter("@Id", buyer.Id);
                SqlParameter objSqlParam_Username = new SqlParameter("@Username", buyer.UserName);
                SqlParameter objSqlParam_Password = new SqlParameter("@Password", buyer.PassWord);
                SqlParameter objSqlParam_Fullname = new SqlParameter("@Fullname", buyer.FullName);
                SqlParameter objSqlParam_Email = new SqlParameter("@Email", buyer.Email);
                SqlParameter objSqlParam_Mobile = new SqlParameter("@Mobile", buyer.Mobile);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", buyer.Address);
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Username);
                objCom.Parameters.Add(objSqlParam_Password);
                objCom.Parameters.Add(objSqlParam_Fullname);
                objCom.Parameters.Add(objSqlParam_Email);
                objCom.Parameters.Add(objSqlParam_Mobile);
                objCom.Parameters.Add(objSqlParam_Address);
                objCon.Open();
                objCom.ExecuteNonQuery();
                buyerRegistered = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CRMSException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return buyerRegistered;

        }


        public bool BuyerLogin(string username, string password)
        {
            bool isUserSearched = false;
            SqlConnection connection = new SqlConnection(
               ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand cmd = new SqlCommand();
            try
            {
                connection.Open();
                cmd.Connection = connection;
                cmd = new SqlCommand("[46008057].Usp_BuyerLogin", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@pass", password);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    isUserSearched = true;
                }

            }
            catch (Exception cex)
            {
                throw new CRMSException(cex.Message);
            }
            finally
            {
                connection.Close();
            }
            return isUserSearched;
        }


        public bool SellerLogin(string username, string password)
        {
            bool isUserSearched = false;
            SqlConnection connection = new SqlConnection(
               ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand cmd = new SqlCommand();
            try
            {
                connection.Open();
                cmd.Connection = connection;
                cmd = new SqlCommand("[46008057].Usp_SellerLogin", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    isUserSearched = true;
                }

            }
            catch (Exception cex)
            {
                throw new CRMSException(cex.Message);
            }
            finally
            {
                connection.Close();
            }
            return isUserSearched;
        }
    }
}
