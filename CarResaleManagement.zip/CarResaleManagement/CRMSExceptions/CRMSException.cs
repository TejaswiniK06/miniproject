﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRMSExceptions
{
  public   class CRMSException :   ApplicationException
    {


        
            public CRMSException() : base()
            {

            }
            public CRMSException(string message) : base(message)
            {

            }
            public CRMSException(string message, Exception innerException) : base(message, innerException)
            {

            }
        }
    
}
