﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRMSDAL;
using CRMSEntities;
using CRMSExceptions;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
namespace CRMSBLL
{
    public class CRMSBL
    {
        public static bool Validate(CarEntity cr)
        {
            bool validate = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (!Regex.IsMatch(cr.Description, @"[\w\.\s\,]{150,}"))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "description should be minimum 150 characters long");
                }
                if (cr.PurchaseYear > DateTime.Now.Year)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Date should be before today");
                }
                if (cr.ExpectedPrice <= 0)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Price should be greater than zero");
                }
                if (cr.AddedDate.Date != DateTime.Now.Date)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Added date will be current date");
                }
                if (cr.Title == String.Empty || cr.Description == String.Empty || cr.Model == String.Empty || cr.Brand == String.Empty || cr.RCStatus == String.Empty || cr.PurchaseYear.ToString() == String.Empty || cr.ExpectedPrice.ToString() == String.Empty || cr.AddedDate.Date.ToString() == String.Empty)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "All Fields are  mandatory");
                }


                if (validate == false)

                    throw new CRMSException(sb.ToString());
            }
            catch (CRMSException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }
        public static bool ValidateSeller(SellerEntity seller)
        {
            bool validate = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (!Regex.IsMatch(seller.PassWord, @"^[A-Za-z0-9]{8,15}$"))
                {


                    validate = false;
                    sb.Append(Environment.NewLine + "Password should be eight characters only and no special characters");
                }
                if (!Regex.IsMatch(seller.Email, @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Email should be in valid format");
                }
                if (!Regex.IsMatch(seller.Mobile, @"^[\d]{10}$"))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Mobile no. should contain 10 numbers ");
                }

                if (seller.UserName == String.Empty || seller.PassWord == String.Empty || seller.FullName == String.Empty || seller.Email == String.Empty || seller.Mobile == String.Empty || seller.Address == String.Empty)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "All Fields are  mandatory");
                }
                if (validate == false)

                    throw new CRMSException(sb.ToString());
            }
            catch (CRMSException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }

        public static bool Validate(InterestRequests request)
        {
            bool validate = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (request.RequestedDate.Date != DateTime.Now.Date)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Added date will be current date");
                }
                if (request.Message == String.Empty)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Message should be mandatory");
                }
                if (request.Status != "Accepted" || request.Status != "Rejected" || request.Status != "Pending")
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Status should be Accepted or rejected or pending");
                }


                if (validate == false)

                    throw new CRMSException(sb.ToString());
            }
            catch (CRMSException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }



        public bool SellerRegistrationDetailsBLL(SellerEntity seller)
        {
            bool issellerRegistered = false;
            try

            {
                if (ValidateSeller(seller))
                {
                    CRMSDal crdal = new CRMSDal();
                    issellerRegistered = CRMSDal.SellerRegistrationDetails(seller);

                }
            }
            catch (CRMSException cex)
            {
                throw cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return issellerRegistered;
        }

        public bool SellerLoginBL(string Username, string Password)
        {
            bool sellerSearched = false;
            try
            {
                CRMSDal crdal = new CRMSDal();
                sellerSearched = crdal.SellerLogin(Username, Password);
            }
            catch (CRMSException cex)
            {
                throw cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sellerSearched;
        }



        public static bool AddCarbySellerBLL(CarEntity car, InterestRequests requests)
        {
            bool added = false;
            try
            {
                if (Validate(car))
                {
                    CRMSDal crdal = new CRMSDal();
                    added = crdal.AddCarbySeller(car, requests);
                }
            }
            catch (CRMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }

        public bool RemoveCarBySellerBLL(int Id, InterestRequests ir)
        {
            bool isDeleted = false;
            try
            {
                CRMSDal crdal = new CRMSDal();
                isDeleted = crdal.RemoveCarBySeller(Id, ir);

            }
            catch (CRMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isDeleted;
        }


        public bool UpdateCarBySellerBLL(CarEntity Car)
        {
            bool isUpdated = false;
            try
            {
                CRMSDal crdal = new CRMSDal();
                isUpdated = crdal.UpdateCarBySeller(Car);

            }
            catch (CRMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isUpdated;
        }

        public DataTable SearchByIdBLL(int Id)
        {
            DataTable dt = null;

            try
            {

                CRMSDal crdal = new CRMSDal();
                dt = crdal.SearchByIdDal(Id);

            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;
        }

        public DataTable DisplayAllBLL()
        {
            DataTable dt;

            try
            {

                CRMSDal crdal = new CRMSDal();
                dt = crdal.DisplayAll();


            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;
        }

        public bool BuyerRegistrationDetailsBLL(BuyerEntity buyer)
        {
            bool buyerRegistered = false;
            try

            {
                CRMSDal crdal = new CRMSDal();
                buyerRegistered = CRMSDal.BuyerRegistrationDetails(buyer);

            }
            catch (CRMSException cex)
            {
                throw cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return buyerRegistered;
        }

        public bool BuyerLoginBL(string Username, string Password)
        {
            bool sellerSearched = false;
            try
            {
                CRMSDal crdal = new CRMSDal();
                sellerSearched = crdal.SellerLogin(Username, Password);
            }
            catch (CRMSException cex)
            {
                throw cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sellerSearched;
        }

        public DataTable SearchCarModelbyBuyerBLL(String Model, String Brand)
        {
            DataTable dt = null;

            try
            {

                CRMSDal crdal = new CRMSDal();
                dt = crdal.SearchCarModelbyBuyer(Model, Brand);
            }
            catch (Exception ex)

            {
                throw ex;
            }
            return dt;
        }
    }
}

    

