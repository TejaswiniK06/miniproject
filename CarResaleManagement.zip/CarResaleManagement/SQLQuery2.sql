use Training_19Sep19_Chennai

create schema [46008057]

create table [46008057].Cars(Id int Primary Key Identity(1,1),
Title   Text not null,
Description Text not null,
Model varchar(50) not null,
Brand varchar(50) not null,
RCStatus Text not null,
PurchaseYear  int not null,
SellerId int Foreign Key(SellerId) REFERENCES [46008057].SellerEntity(Id) not null,
ExpectedPrice int Not Null  CHECK (ExpectedPrice>0),
AddedDate DateTime
)
select * from  [46008057].Cars
Insert into [46008057].Cars values('Volks','gooooooooooooooooood','i10','shift','awesome','1994','3','100','1999/9/12')
Insert into [46008057]. Cars values('gsdfjsdfj','gooooooooooooooooooooooooooooooood','i20','shift','awesome','1990','1','1000000','1999/9/12')
Insert into [46008057]. Cars values('gsdf','gooooooooooooooooood','yxx','shift','awesome','1990','1','1000000','1999/9/12')
Insert into [46008057].Cars values('Verna','very speed','modern','x10','awesome','1900','3','100','1999/9/12')

drop table [46008057].Cars
 drop table [46008057].SellerEntity
 ***************************************************************************************************************************************************************

alter proc [46008057].usp_AddcarbySeller(
 
 @Title Text,
  @Description Text,
  @Model varchar(50),
  @Brand varchar(50),
  @RCStatus Text,
  @PurchaseYear int,
  @Sellerid int,
  @ExpectedPrice int)
  
 AS
BEGIN
 DECLARE @AddedDate datetime
SET @AddedDate = Getdate() 

		Insert into [46008057].Cars
		(Title,Description,Model,Brand ,RCStatus,PurchaseYear ,Sellerid ,ExpectedPrice,AddedDate)
		VALUES
		(@Title ,@Description ,@Model , @Brand , @RCStatus ,@PurchaseYear, @Sellerid , @ExpectedPrice,@AddedDate)
		
	END	
go






exec [46008057].usp_AddcarbySeller 'vinni','this is very userful ffor eveery ononce it lost allthe features are lost this is liked byh everyokne it is an arec color and wheels of this car is very smmoth and the discription of the car is very high for the users ','benz','shift',
                        'good','1990','2','1000000'

select * from [46008057].Cars
-- ********************************************************************************************************************************************
 alter procedure  [46008057].usp_RemovecarbySeller(
	@Id int,
	@Status varchar(50)
)
AS begin 
     

 --DELETE FROM [46008057].InterestRequests WHERE Id IN
 --  (SELECT Id  FROM  [46008057].Cars WHERE Id=@Id) 
   delete from [46008057].Cars  where Id=@Id
   update [46008057].InterestRequests set Status =@Status where CarId=@Id 
end
go

drop proc  [46008057].usp_RemovecarbySeller

exec  [46008057].usp_RemovecarbySeller  13,'Rejected'

select * from [46008057].Cars

select * from [46008057].InterestRequests
 
-- **********************************************************************************************************************************************
 
create procedure [46008057].usp_UpdatecarbySeller(
    @Id int,
	@Title Text,
	@Description  Text,
	@Model Text,
	@Brand Text,
	@RCStatus Text,
	@PurchaseYear  int,
	@SellerId int ,
	@ExpectedPrice int,
	@AddedDate Date
	)
	as
begin
update[46008057].Cars
set Title=@Title,Description=@Description,Model=@Model,Brand=@Brand,RCStatus=@RCStatus,PurchaseYear=@PurchaseYear,SellerId =@SellerId,ExpectedPrice=@ExpectedPrice,AddedDate=@AddedDate
where Id=@Id
end
exec [46008057]. usp_UpdatecarbySeller 6, 'benz','gooooooooooooooooooooooooooooooood','xuv300','shift','awesome','1990','1','10000','1999/9/12'
drop proc [46008057].usp_UpdatecarbySeller

----------------------------------------------------------------------------------------------------------------------------------------------------------------
create procedure [46008057].usp_SearchcarBySeller
(
	@Id int
	
)
As
Begin
select * from Cars
where Id=@Id
end
exec [46008057].usp_SearchcarBySeller 2
-----------------------------------------------------------------------------------------------------------------------------------
Create proc [46008057].usp_SellerRegistration(
    
	@Username Text,
	@Password Text,
	@Fullname Text,
	@Email Text,
	@Mobile Text,
	@Address Text
	)
As
begin
insert into [46008057].SellerEntity (Username,Password,Fullname,Email,Mobile,Address) values (@Username,@Password,@Fullname,@Email,@Mobile,@Address)
end 
GO 
exec [46008057].usp_SellerRegistration 'raju','vinni@123','ganipisetty','ganipisettyvineela@gmail.com','9951336522','parchoor'
select * from [46008057].SellerEntity
--------------------------------------------------------------------------------------------------------------------------------------------------
Create proc [46008057].usp_BuyerRegistration(
    @Username Text,
	@Password Text,
	@Fullname Text,
	@Email Text,
	@Mobile Text,
	@Address Text
	)
As
begin
insert into [46008057].BuyerEntity (Username,Password,Fullname,Email,Mobile,Address) values (@Username,@Password,@Fullname,@Email,@Address)
end 
GO 
----------------------------------------------------------------------------------------------------------------------------
create proc [46008057].Usp_SellerLogin(
    @Username varchar(50),
	@Password varchar(50))
As
begin
    if exists (select UserName from [46008057].SellerEntity where UserName = @username)
    begin
        select * from [46008057].SellerEntity where UserName=@username and Password=@password
    end
    else
    begin
        raiserror('Account does not exists', 1,1)
    end
end
Go
exec [46008057].Usp_SellerLogin 'raju','vinni@123'
----------------------------------------------------------------------------------------
create proc [46008057].usp_displayCars
as
begin
select * from [46008057].Cars
end
exec [46008057].usp_displayCars
------------------------------------------------------------------------------------------------------------
create proc  [46008057].Usp_BuyerLogin(
    @Username varchar(50),
	@Password varchar(50))
As
begin
    if exists (select UserName from [46008057].BuyerEntity  where UserName = @username)
    begin
        select * from [46008057].BuyerEntity  where UserName=@username and Password=@password
    end
    else
    begin
        raiserror('Account does not exists', 1,1)
    end
end
Go
exec [46008057].Usp_BuyerLogin 'revathi','revathi@123'
select * from 
--------------------------------------------------------------------------------------------------------
select * from [46008057].InterestRequests 
alter proc [46008057].usp_InterestRequests
(
@BuyerId int,
@RequestedDate Date,
@Message Text,
@Model varchar(30),
@Status varchar(30))
As
begin
insert into [46008057].InterestRequests (BuyerId,RequestedDate,Message,CarId,Status) values (@BuyerId,@RequestedDate,@Message,(Select Id from [46008057].Cars where Model= @Model),@Status)
end 
Go
exec  [46008057].usp_InterestRequests '1','1998/9/2','i want car','maruthi','awesome'
drop proc [46008057].usp_InterestRequests
select * from [46008057].InterestRequests 
------------------------------------------------------------------------
create proc [46008057].usp_UpdateInterestRequests
(
@Id int,
@Status varchar(50)
)
as
begin
update [46008057].InterestRequests 
set Status=@Status
where Id=@Id
end
exec  [46008057].usp_UpdateInterestRequests '2','morecars wanted '

select * from [46008057].InterestRequests 

-----------------------------------------------------------------------------------------------------------------------------------
create proc [46008057].usp_viewInterestRequests

as
begin
select * from [46008057].InterestRequests 
end
exec [46008057].usp_viewInterestRequests
-----------------------------------------------------------------------------------------------------------------------------
create table [46008057].SellerEntity(Id int Primary Key Identity(1,1),Username varchar(30) Not Null Unique ,Password varchar(50) Not Null,
Fullname Text Not Null,Email Text Not Null,Mobile  Text Not Null,Address Text)

select * from [46008057].SellerEntity

insert into [46008057].SellerEntity values('vineela','vinni@123','ganipisetty','ganipisettyvineela@gmail.com','9951336522','parchoor')

drop table [46008057].SellerEntity
---------------------------------------------------------------------------------------------------******************************************
create table [46008057].BuyerEntity(Id int Primary Key Identity(1,1),Username varchar(30) Not Null Unique ,Password varchar(50) Not Null,
Fullname Text Not Null,Email Text Not Null,Mobile  Text Not Null,Address Text)
select * from [46008057].BuyerEntity
insert into [46008057].BuyerEntity values('revathi','revathi@123','nandivada','nandivada@gmail.com','9951330088','parchoor')
*******************************************************************************************************************************************
create table  [46008057].InterestRequests (Id int Primary Key Identity(1,1),BuyerId int Foreign Key(BuyerId) REFERENCES [46008057].BuyerEntity(Id) not null,
RequestedDate Date Not null ,Message Text Not Null,CarId int Foreign Key(CarId) REFERENCES [46008057].Cars Not Null,Status varchar(30) Not Null )

select * from [46008057].InterestRequests 
insert into [46008057].InterestRequests values ('1','1998/9/2','i want car','1','awesome')
drop table [46008057].InterestRequests 
-------------------------------------------------------------------------------------------------------------------------------c******************************
create procedure [46008057].usp_SearchcarmodelbyBuyer(
	@Model varchar(50),
	@Brand varchar(50))
As
Begin
select * from [46008057]. Cars where (Model=@Model AND Brand=@Brand)
end

exec [46008057].usp_SearchcarmodelbyBuyer 'i20','shift'
drop proc  [46008057].usp_SearchcarmodelbyBuyer
**************************************************************************************************************************************************************



