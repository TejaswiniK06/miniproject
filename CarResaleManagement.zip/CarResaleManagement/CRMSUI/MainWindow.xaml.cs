﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CRMSExceptions;
using CRMSEntities;
using CRMSBLL;

namespace CRMSUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnUpate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CarEntity Car = new CarEntity();

                Car.Id = int.Parse(txtId.Text);
                Car.Title = txtTitle.Text;
                Car.Description = txtDes.Text;
                Car.Model = txtModel.Text;
                Car.Brand = txtBrand.Text;
                Car.RCStatus = txtRCStatus.Text;
                Car.PurchaseYear = int.Parse(txtPYear.Text);
                Car.SellerId = Convert.ToInt32(txtSId.Text);
                Car.ExpectedPrice = Convert.ToInt32(txtEPrice.Text);
                Car.AddedDate = DateTime.Today;
                CRMSBL bLL = new CRMSBL();

                if (bLL.UpdateCarBySellerBLL(Car))
                {
                    MessageBox.Show("Car " + Car.Model + "  details Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to update car " + Car.Model + " details");
                }
            }
            catch (CRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
    }

