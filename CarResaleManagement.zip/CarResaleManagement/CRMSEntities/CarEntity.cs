﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRMSEntities
{
    
    [Serializable]
    public class CarEntity
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Model { get; set; }
        public string Brand { get; set; }
        public string RCStatus { get; set; }
        public int PurchaseYear { get; set; }
        public int SellerId { get; set; }
        public int ExpectedPrice { get; set; }
        public DateTime AddedDate { get; set; }
    }


    [Serializable]
    public class SellerEntity
    {

        public int Id { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
    }

    [Serializable]
    public class BuyerEntity
    {

        public int Id { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
    }


    [Serializable]
    public class InterestRequests
    {

        public int Id { get; set; }
        public int BuyerId { get; set; }
        public DateTime RequestedDate { get; set; }
        public string Message { get; set; }
        public int CarId { get; set; }
        public string Status { get; set; }

    }
}


