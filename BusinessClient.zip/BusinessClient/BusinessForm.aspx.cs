﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessClient.ServiceReference1;

namespace BusinessClient
{
    public partial class BusinessForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            BusinessServiceClient businessServiceClient = new BusinessServiceClient();
            Business business = new Business();

            // elector.ElectorID = Convert.ToInt32(txtId.Text);
            business.FirmName = txtname.Text;
            business.ActivityNature = ddlactivity.SelectedItem.ToString();
            business.FirmAddress = txtfaddress.Text;
            business.OwnerName = txtoname.Text;
            business.MobileNo = txtmobile.Text;
            business.EmailAddress = txteaddress.Text;

            businessServiceClient.Add(business);




            if (businessServiceClient != null)

            {

                lblstatus.Text = " Data Added Successfully";

            }

            else

            {

                lblstatus.Text = " data not Added";

            }
        }

        protected void ddlactivity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}