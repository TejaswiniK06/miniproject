﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JPortalEntity
{

    [Serializable]

    public class JPEntities

    {

        public string JobID { get; set; }

        public string Employer { get; set; }

        public string Address { get; set; }

        public string ContactNumber { get; set; }

        public string ContactEmailID { get; set; }

        public string SkillsRequired { get; set; }

        public string Qualification { get; set; }

        public string Location { get; set; }

        public long Salary { get; set; }

        public int NoOfVacancies { get; set; }



    }

    [Serializable]

    public class UserEntities

    {

        public string UserID { get; set; }

        public string Password { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Age { get; set; }

        public string Gender { get; set; }

        public string Address { get; set; }

        public string PhoneNo { get; set; }

        public string UserType { get; set; }



    }
}
