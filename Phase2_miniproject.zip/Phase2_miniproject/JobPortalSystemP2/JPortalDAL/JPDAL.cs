﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using JPortalException;
using JPortalEntity;
using System.Windows;

namespace JPortalDAL
{
    public class JPDAL
    {
        //SqlConnection con;

        public static bool AddUserDetails(UserEntities user)
        {
            bool userAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("sp_Insert_userJPSp2_46008205", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_userID = new SqlParameter("@userID", user.UserID);
                SqlParameter objSqlParam_UserPassword = new SqlParameter("@UserPassword", user.Password);
                SqlParameter objSqlParam_UserFirstName = new SqlParameter("@UserFirstName", user.FirstName);
                SqlParameter objSqlParam_UserLastName = new SqlParameter("@UserLastName", user.LastName);
                SqlParameter objSqlParam_UserAge = new SqlParameter("@UserAge", user.Age);
                SqlParameter objSqlParam_UserGender = new SqlParameter("@UserGender", user.Gender);
                SqlParameter objSqlParam_UserAddress = new SqlParameter("@UserAddress", user.Address);
                SqlParameter objSqlParam_UserContact = new SqlParameter("@UserContact", user.PhoneNo);
                SqlParameter objSqlParam_userType = new SqlParameter("@userType", user.UserType);

                objCom.Parameters.Add(objSqlParam_userID);
                objCom.Parameters.Add(objSqlParam_UserPassword);
                objCom.Parameters.Add(objSqlParam_UserFirstName);
                objCom.Parameters.Add(objSqlParam_UserLastName);
                objCom.Parameters.Add(objSqlParam_UserAge);
                objCom.Parameters.Add(objSqlParam_UserGender);
                objCom.Parameters.Add(objSqlParam_UserAddress);
                objCom.Parameters.Add(objSqlParam_UserContact);
                objCom.Parameters.Add(objSqlParam_userType);

                objCon.Open();
                objCom.ExecuteNonQuery();
                userAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return userAdded;

        }

        public static bool AddJobDetailsDAL(JPEntities job)
        {
            bool isJobAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("sp_Insert_jobJPSp2_46008205", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_JobID = new SqlParameter("@JobID", job.JobID);
                SqlParameter objSqlParam_jobEmployer = new SqlParameter("@jobEmployer", job.Employer);
                SqlParameter objSqlParam_jobEmployerAddress = new SqlParameter("@jobEmployerAddress", job.Address);
                SqlParameter objSqlParam_JobEmployerContactNumber = new SqlParameter("@JobEmployerContactNumber", job.ContactNumber);
                SqlParameter objSqlParam_jobEmployerContactEmailID = new SqlParameter("@jobEmployerContactEmailID", job.ContactEmailID);
                SqlParameter objSqlParam_jobSkillsRequired = new SqlParameter("@jobSkillsRequired", job.SkillsRequired);
                SqlParameter objSqlParam_jobQualification = new SqlParameter("@jobQualification", job.Qualification);
                SqlParameter objSqlParam_jobLocation = new SqlParameter("@jobLocation", job.Location);
                SqlParameter objSqlParam_jobSalary = new SqlParameter("@jobSalary", job.Salary);
                SqlParameter objSqlParam_jobNoOfVacancies = new SqlParameter("@jobNoOfVacancies", job.NoOfVacancies);

                objCom.Parameters.Add(objSqlParam_JobID);
                objCom.Parameters.Add(objSqlParam_jobEmployer);
                objCom.Parameters.Add(objSqlParam_jobEmployerAddress);
                objCom.Parameters.Add(objSqlParam_JobEmployerContactNumber);
                objCom.Parameters.Add(objSqlParam_jobEmployerContactEmailID);
                objCom.Parameters.Add(objSqlParam_jobSkillsRequired);
                objCom.Parameters.Add(objSqlParam_jobQualification);
                objCom.Parameters.Add(objSqlParam_jobLocation);
                objCom.Parameters.Add(objSqlParam_jobSalary);
                objCom.Parameters.Add(objSqlParam_jobNoOfVacancies);

                objCon.Open();
                objCom.ExecuteNonQuery();
                isJobAdded = true;
            }
            catch (JPException ex)
            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isJobAdded;

        }      

        public static List<UserEntities> ListAllUserDetailsDAL()
        {
            List<UserEntities> users = new List<UserEntities>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("sp_Display_userJPSp2_46008205", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;

                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    UserEntities userData = new UserEntities();
                    userData.UserID = (objDR[0]).ToString();
                    userData.Password = (objDR[1]).ToString();
                    userData.FirstName = (objDR[2]).ToString();
                    userData.LastName = (objDR[3]).ToString();
                    userData.Age = Convert.ToInt32(objDR[4]);
                    userData.Gender = (objDR[5]).ToString();
                    userData.Address = (objDR[6]).ToString();
                    userData.PhoneNo = (objDR[7]).ToString();
                    userData.UserType = (objDR[8]).ToString();
                    users.Add(userData);
                }
            }

            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return users;
        }


        public static List<JPEntities> ListAllJobDetailsDAL()
        {


            List<JPEntities> jobs = new List<JPEntities>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("sp_Display_jobJPSp2_46008205", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;

                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    JPEntities jobData = new JPEntities();
                    jobData.JobID = (objDR[0]).ToString();
                    jobData.Employer = (objDR[1]).ToString();
                    jobData.Address = (objDR[2]).ToString();
                    jobData.ContactNumber = (objDR[3]).ToString();
                    jobData.ContactEmailID = (objDR[4]).ToString();
                    jobData.SkillsRequired = (objDR[5]).ToString();
                    jobData.Qualification = (objDR[6]).ToString();
                    jobData.Location = (objDR[7]).ToString();
                    jobData.Salary = Convert.ToInt32(objDR[8]);
                    jobData.NoOfVacancies = Convert.ToInt32(objDR[8]);
                    jobs.Add(jobData);
                }
            }

            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return jobs;

        }



        public static bool DeleteUserDetailsDAL(String UserID)

        {
            bool isUserDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("sp_Delete_userJPSp2_46008205", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@userID",Int32.Parse(UserID));
                //
                objCom.Parameters.Add(objSqlParam_Id);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                isUserDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return isUserDeleted;


        }
        public static bool DeleteJobDetailsDAL(String JobID)

        {
            bool isJobDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("sp_Delete_jobJPSp2_46008205", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_jId = new SqlParameter("@jobID", Int32.Parse(JobID));
                //
                objCom.Parameters.Add(objSqlParam_jId);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                isJobDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return isJobDeleted;


        }

       

        public static bool UpdateUserDetailDAL(UserEntities updatedUser)

        {
            bool userUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[UpdateCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_UserPassword = new SqlParameter("@UserPassword", updatedUser.Password);
                SqlParameter objSqlParam_UserFirstName = new SqlParameter("@UserFirstName", updatedUser.FirstName);
                SqlParameter objSqlParam_UserLastName = new SqlParameter("@UserLastName", updatedUser.LastName);
                SqlParameter objSqlParam_UserAge = new SqlParameter("@UserAge", updatedUser.Age);
                SqlParameter objSqlParam_UserGender = new SqlParameter("@UserGender", updatedUser.Gender);
                SqlParameter objSqlParam_UserAddress = new SqlParameter("@UserAddress", updatedUser.Address);
                SqlParameter objSqlParam_UserContact = new SqlParameter("@UserContact", updatedUser.PhoneNo);
                SqlParameter objSqlParam_userType = new SqlParameter("@userType", updatedUser.UserType);
                //
                objCon.Open();
                objCom.Parameters.Add(objSqlParam_UserPassword);
                objCom.Parameters.Add(objSqlParam_UserFirstName);
                objCom.Parameters.Add(objSqlParam_UserLastName);
                objCom.Parameters.Add(objSqlParam_UserAge);
                objCom.Parameters.Add(objSqlParam_UserGender);
                objCom.Parameters.Add(objSqlParam_UserAddress);
                objCom.Parameters.Add(objSqlParam_UserContact);
                objCom.Parameters.Add(objSqlParam_userType);
                objCom.ExecuteNonQuery();
                userUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return userUpdated;

        }

        public static bool UpdateJobDetailDAL(JPEntities updatedJob)

        {
            bool jobUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008173].[UpdateCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_jobEmployer = new SqlParameter("@jobEmployer", updatedJob.Employer);
                SqlParameter objSqlParam_jobEmployerAddress = new SqlParameter("@jobEmployerAddress", updatedJob.Address);
                SqlParameter objSqlParam_JobEmployerContactNumber = new SqlParameter("@JobEmployerContactNumber", updatedJob.ContactNumber);
                SqlParameter objSqlParam_jobEmployerContactEmailID = new SqlParameter("@jobEmployerContactEmailID", updatedJob.ContactEmailID);
                SqlParameter objSqlParam_jobSkillsRequired = new SqlParameter("@jobSkillsRequired", updatedJob.SkillsRequired);
                SqlParameter objSqlParam_jobQualification = new SqlParameter("@jobQualification", updatedJob.Qualification);
                SqlParameter objSqlParam_jobLocation = new SqlParameter("@jobLocation", updatedJob.Location);
                SqlParameter objSqlParam_jobSalary = new SqlParameter("@jobSalary", updatedJob.Salary);
                SqlParameter objSqlParam_jobNoOfVacancies = new SqlParameter("@jobNoOfVacancies", updatedJob.NoOfVacancies);
                
                //
                objCon.Open();
                objCom.Parameters.Add(objSqlParam_jobEmployer);
                objCom.Parameters.Add(objSqlParam_jobEmployerAddress);
                objCom.Parameters.Add(objSqlParam_JobEmployerContactNumber);
                objCom.Parameters.Add(objSqlParam_jobEmployerContactEmailID);
                objCom.Parameters.Add(objSqlParam_jobSkillsRequired);
                objCom.Parameters.Add(objSqlParam_jobQualification);
                objCom.Parameters.Add(objSqlParam_jobLocation);
                objCom.Parameters.Add(objSqlParam_jobSalary);
                objCom.Parameters.Add(objSqlParam_jobNoOfVacancies);
                objCom.ExecuteNonQuery();
                jobUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objCon.Close();
            }
            return jobUpdated;

        }

        public static UserEntities SearchUserDAL(int userId)
        {
            UserEntities objUser = new UserEntities();
            try
            {
                SqlConnection objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("sp_Search_userJPSp2_46008205", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                objCom.Parameters.AddWithValue("@userID", userId);
                objCon.Open();
                SqlDataReader dr =  objCom.ExecuteReader();
                if (dr.Read())
                {
                    objUser.UserID = (dr[0]).ToString();
                    objUser.Password = (dr[1]).ToString();
                    objUser.FirstName = (dr[2]).ToString();
                    objUser.LastName = (dr[3]).ToString();
                    objUser.Age = Convert.ToInt32((dr[4]).ToString());
                    objUser.Gender = (dr[5]).ToString();
                    objUser.Address = (dr[6]).ToString();
                    objUser.PhoneNo = (dr[7]).ToString();
                    objUser.UserType = (dr[8]).ToString();
                }
                else
                {
                    Console.WriteLine("---------------------no");
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            return objUser;
        }
        public static JPEntities SearchJobDAL(int jobId)
        {
            JPEntities objJob = new JPEntities();
            try
            {
                SqlConnection objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("sp_SearchjobJPSp2_46008205", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                objCom.Parameters.AddWithValue("@JobID", jobId);
                objCon.Open();
                SqlDataReader dr = objCom.ExecuteReader();
                if (dr.Read())
                {
                    objJob.JobID = (dr[0]).ToString();
                    objJob.Employer = (dr[1]).ToString();
                    objJob.Address = (dr[2]).ToString();
                    objJob.ContactNumber = (dr[3]).ToString();
                    objJob.ContactEmailID = (dr[4]).ToString();
                    objJob.SkillsRequired = (dr[5]).ToString();
                    objJob.Qualification = (dr[6]).ToString();
                    objJob.Location = (dr[7]).ToString();
                    objJob.Salary = Convert.ToInt32((dr[8]));
                    objJob.NoOfVacancies = Convert.ToInt32((dr[8]).ToString());
                }
                else
                {
                    Console.WriteLine("---------------------no");
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new JPException(objSqlEx.Message);
            }
            catch (Exception e)
            {
                throw e;
            }
            return objJob;
        }
    }
}
