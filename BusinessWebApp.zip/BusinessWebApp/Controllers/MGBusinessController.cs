﻿using BusinessWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BusinessWebApp.Controllers
{
    public class MGBusinessController : Controller
    {
        BusinessEntities bs = new BusinessEntities();
        // GET: MGBusiness
        public ActionResult Index()                 //action result for index page
        {
            return View(bs.Businesses.ToList());
        }
        public ActionResult ActivityNature()      // data from business table where details are displayed based on trade
                                                   //ordered according to business id
        {
            var Nature = from Business in bs.Businesses
                      where (Business.ActivityNature == "Trade")
                      orderby Business.BusinessId ascending
                      select Business;
            return View(Nature);                         //returning view page of activity nature

        }
    }
}