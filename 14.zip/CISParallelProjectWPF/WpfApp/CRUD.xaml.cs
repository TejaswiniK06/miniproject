﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
 using CarInfoBLL;
using CarInfoException;
using CarInfoEntities;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for CRUD.xaml
    /// </summary>
    public partial class CRUD : Window
    {
        public CRUD()
        {
            InitializeComponent();
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {
            Addcar();
        }

        private void Addcar()
        {
            try
            {
                MainCar mainCar = new MainCar();
                Manufacturer manuf = new Manufacturer();
                mainCar.Model = txtModel.Text;
                mainCar.Engine = txtEng.Text;
                mainCar.BHP = int.Parse(txtBHP.Text);
                mainCar.Mileage = int.Parse(txtMileage.Text);
                mainCar.Seat = int.Parse(txtSeat.Text);
                mainCar.AirBagDetails = txtAirBag.Text;
                mainCar.BootSpace = txtBootSpace.Text;
                mainCar.Price = txtPrice.Text;
                manuf.ManufacturerName = txtManfName.Text;
                manuf.ContactPerson = txtConPerson.Text;
                manuf.RegisteredOffice = txtRegOff.Text;
                mainCar.TypeId = Convert.ToInt32(cmbTypeId.SelectedValue);
                mainCar.TransmissionId = Convert.ToInt32(cmbTransId.SelectedValue);

                CarBLL bLL = new CarBLL();

                if (bLL.AddByAdminBLl(mainCar, manuf))
                {
                    MessageBox.Show("Car " + mainCar.Model + " details added Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to add car" + mainCar.Model + " details");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetTrans()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTransmissionTableBLL();
                cmbTransId.ItemsSource = translist.DefaultView;
                cmbTransId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTransId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTypeTableBLL();
                cmbTypeId.ItemsSource = translist.DefaultView;
                cmbTypeId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTypeId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetTypeId();
            GetTrans();
           

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            deletecar();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            AdminPage adminPage = new AdminPage();
            adminPage.Show();
            this.Close();
        }

        private void BtnListby_Click(object sender, RoutedEventArgs e)
        {
            AdminPage adminPage = new AdminPage();
            adminPage.Show();
            this.Close();
        }
        private void deletecar()
        {
            try
            {
                MainCar mainCar = new MainCar();
                string Model = txtModel.Text;
                CarBLL bLL = new CarBLL();

                if (bLL.DeleteBLL(Model))
                {
                    MessageBox.Show("Car " +Model+" Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to delete car " + Model );
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void DisplayforCarTable()
        {
            CarBLL bLL = new CarBLL();
            DataTable dt = bLL.DisplayCarTableBAL();
            dg.DataContext = dt;
            


            
        }

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            AdminPage admin = new AdminPage();
            admin.Show();
            this.Close();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            txtModel.Text = "";
            txtEng.Text = "";
            (txtBHP.Text) = "";
            (txtMileage.Text) = "";
            (txtSeat.Text) = "";
            txtAirBag.Text = "";
            txtBootSpace.Text = "";
            txtPrice.Text = "";
            txtManfName.Text = "";
            txtConPerson.Text = "";
            txtRegOff.Text = "";
            (cmbTypeId.Text) = "";
            (cmbTransId.Text) = "";
            DisplayforCarTable();
        }
    }
}
