﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoException;
using CarInfoEntities;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Window
    {
        public AdminPage()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            CRUD cRUD = new CRUD();
            cRUD.Show();
            this.Hide();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
           UpdateWindow updateWindow = new UpdateWindow();
            updateWindow.Show();
            this.Hide();
        }

        private void BtnSort_Click(object sender, RoutedEventArgs e)
        {
            Searchmodel();
        }

        private void Btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayWPF();
            GetTypeId();
        }
        private void DisplayWPF()
        {
            try
            {
                CarBLL bLL = new CarBLL();
                DataTable dt = bLL.DisplayAllBLL();
                dg.DataContext = dt;
                if (dt.Rows.Count > 0)
                {

                    //while (dt.Rows.Count > 0)

                    //{
                    //    //  dt.Rows[0]["Engine"].ToString();
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        cmbModel.Items.Add(dt.Rows[x]["Model"].ToString());
                        cmbmanuf.Items.Add(dt.Rows[x]["ManufacturerName"].ToString());


                    }


                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Searchmodel()
        {
            try
            {
                // MainCar car = new MainCar();
                CarBLL bLL = new CarBLL();
                string model = (cmbModel.Text);

                DataTable dt = bLL.SearchByModelBLL(model);
                dg.DataContext = dt;



            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnlistbyMan_Click(object sender, RoutedEventArgs e)
        {
            Listby();
        }

        private void Listby()
        {
            try
            {
                CarBLL bLL = new CarBLL();

              
                   
                        

                
                string cartype = cmbTypeId.Text;
                string manufacturername = cmbmanuf.Text;
               DataTable dt = bLL.SearchByAdminBLL(manufacturername, cartype);
                dg.DataContext = dt;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBLL bLL = new CarBLL();
            try
            {
                DataTable translist = bLL.GetCarTypeTableBLL();
                cmbTypeId.ItemsSource = translist.DefaultView;
                cmbTypeId.DisplayMemberPath = translist.Columns[1].ColumnName;
                cmbTypeId.SelectedValuePath = translist.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
