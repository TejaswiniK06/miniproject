﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInformationSystemExceptionlayer
{
    public class MyCarException : ApplicationException
    {
        public MyCarException() : base() { }

        public MyCarException(string message) : base(message) { }

        public MyCarException(string message, Exception innerException) : base(message, innerException) { }
    }
}
