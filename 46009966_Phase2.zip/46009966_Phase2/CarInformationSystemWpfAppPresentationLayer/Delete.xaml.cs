﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInformationSystemEntityLayer;
using CarInformationSystemExceptionlayer;
using carInformationSystemBusinessLL;
using System.Data;
using System.Data.SqlClient;

namespace CarInformationSystemWpfAppPresentationLayer
{
    /// <summary>
    /// Interaction logic for Delete.xaml
    /// </summary>
    public partial class Delete : Window
    {
        public Delete()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetManufacturer();
            GetTypeId();
            GetTransmission();
            
        }
        private void GetManufacturer()
        {
            CarDetailsBLL bal = new CarDetailsBLL();
            try
            {
                DataTable designationList = bal.GetManufacturerBLL();

                cmbmanfID.ItemsSource = designationList.DefaultView;
                cmbmanfID.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbmanfID.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetTypeId()
        {
            CarDetailsBLL bal = new CarDetailsBLL();
            try
            {
                DataTable designationList = bal.GetCarTypeBLL();
                cmbcartype.ItemsSource = designationList.DefaultView;
                cmbcartype.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbcartype.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTransmission()
        {
            CarDetailsBLL bal = new CarDetailsBLL();
            try
            {
                DataTable designationList = bal.GetCarTransmissionBLL();
                cmbTransType.ItemsSource = designationList.DefaultView;
                cmbTransType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbTransType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Search()
        {
            try
            {
                string model = txtmodel.Text;
                //
                CarDetailsEntities objcar;

                CarDetailsBLL bLL = new CarDetailsBLL();
                objcar = bLL.SearchCarBL(model);
                if (objcar != null)
                {
                    txtmodel.Text = objcar.Model.ToString();
                    txtID.Text = objcar.Id.ToString();
                    cmbmanfID.SelectedValue = objcar.ManufacturerId.ToString();
                    txtmileage.Text = objcar.Mileage.ToString();
                    txteng.Text = objcar.Engine.ToString();
                    cmbcartype.SelectedValue = objcar.Type.ToString();
                    txtBhp.Text = objcar.BHP.ToString();
                    txtboot.Text = objcar.BootSpace.ToString();
                    txtAirbags.Text = objcar.Airbags.ToString();
                    cmbTransType.SelectedValue = objcar.Transmission.ToString();
                    txtseats.Text = objcar.Seats.ToString();
                    txtprice.Text = objcar.price.ToString();

                }
                else
                {
                    MessageBox.Show("Car Model couldn't be found.");
                }
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            deletecar();
        }
        private void deletecar()
        {

            try
            {
                string model ;
                //
                bool CarDeleted;
                //
                model = (txtmodel.Text);
                //
                CarDetailsBLL bal = new CarDetailsBLL();
                CarDeleted = bal.DeleteCarBL(model);
                if (CarDeleted == true)
                {
                    MessageBox.Show("car details deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Car not  found  so couldn't be deleted.");
                }
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {
            Search();
        }

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.ShowDialog();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.ShowDialog();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            List lt = new List();
            lt.ShowDialog();
        }
    }
}
