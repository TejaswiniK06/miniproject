﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using CarInformationSystemEntityLayer;
using CarInformationSystemExceptionlayer;
using carInformationSystemBusinessLL;

namespace CarInformationSystemWpfAppPresentationLayer
{
    /// <summary>
    /// Interaction logic for LoginFormCar.xaml
    /// </summary>
    public partial class LoginFormCar : Window
    {
        
        public LoginFormCar()
        {
            InitializeComponent();
        }

       
        private void Btnlogin_Click(object sender, RoutedEventArgs e)
        {
          
            // window1.Show(); // Win10 tablet in tablet mode, use this, when sub Window is closed, the main window will be covered by the Start menu.
           
           
            ContentWindow cw = new ContentWindow();
            CarDetailsBLL bLL = new CarDetailsBLL();
            bool login = false;
            string userName = txtusername.Text;
            string password = pbpwd.Password;
            login = bLL.RegistrationSearchBL(userName, password);
            if (login)
            {
                MessageBox.Show("Login Successful");
                cw.ShowDialog();
                
            }
            else
                MessageBox.Show("Enter correct User");
        }
    }
}
