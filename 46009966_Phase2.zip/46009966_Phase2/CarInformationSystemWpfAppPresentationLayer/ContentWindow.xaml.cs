﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarInformationSystemWpfAppPresentationLayer
{
    /// <summary>
    /// Interaction logic for ContentWindow.xaml
    /// </summary>
    public partial class ContentWindow : Window
    {
        public ContentWindow()
        {
            InitializeComponent();
        }

        private void BtnToAdd_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.ShowDialog();
        }

        private void BtnToSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchCar sc = new SearchCar();
            sc.ShowDialog();
        }

        private void BtnToDelete_Click(object sender, RoutedEventArgs e)
        {
            Delete dl = new Delete();
            dl.ShowDialog();
        }

        private void BtnToModify_Click(object sender, RoutedEventArgs e)
        { 
            List lst = new List();
            lst.ShowDialog();
        }

        private void BtnToView_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.ShowDialog();
        }
    }
}
