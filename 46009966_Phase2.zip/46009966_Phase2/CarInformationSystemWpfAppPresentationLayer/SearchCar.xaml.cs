﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInformationSystemEntityLayer;
using CarInformationSystemExceptionlayer;
using carInformationSystemBusinessLL;

namespace CarInformationSystemWpfAppPresentationLayer

{
    /// <summary>
    /// Interaction logic for SearchCar.xaml
    /// </summary>
    public partial class SearchCar : Window
    {
        public SearchCar()
        {
            InitializeComponent();
        }

        
        private void SearchbyModel()
        {
            try
            {
                string model = txtmodel.Text;
                
                CarDetailsEntities objcar;
                
                CarDetailsBLL bLL = new CarDetailsBLL();
                objcar = bLL.SearchCarBL(model);
                if (objcar != null )
                {
                    txtmodel.Text = objcar.Model.ToString();
                    txtID.Text = objcar.Id.ToString();
                    txtmanuftype.Text = objcar.ManufacturerId.ToString();
                    txtmileage.Text = objcar.Mileage.ToString();
                    txteng.Text = objcar.Engine.ToString();
                    txtcartype.Text = objcar.Type.ToString();
                    txtBhp.Text = objcar.BHP.ToString();
                    txtboot.Text = objcar.BootSpace.ToString();
                    txtAirbags.Text = objcar.Airbags.ToString();
                    txtranstype.Text = objcar.Transmission.ToString();
                    txtseats.Text = objcar.Seats.ToString();
                    txtprice.Text = objcar.price.ToString();
                 
                }
                else
                {
                    MessageBox.Show("Car Model  couldn't be empty.");
                }
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchByModel_Click(object sender, RoutedEventArgs e)
        {
            SearchbyModel();
        }

        private void Txteng_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
