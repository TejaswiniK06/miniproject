﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using CarInformationSystemEntityLayer;
using CarInformationSystemExceptionlayer;
using carInformationSystemBusinessLL;


namespace CarInformationSystemWpfAppPresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetCars();
            GetManufacturer();
            GetTypeId();
            GetTransmission();
        }
        private void GetManufacturer()
        {
            CarDetailsBLL bal = new CarDetailsBLL();
            try
            {
                DataTable designationList = bal.GetManufacturerBLL();

                cmbmanfID.ItemsSource = designationList.DefaultView;
                cmbmanfID.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbmanfID.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetTypeId()
        {
            CarDetailsBLL bal = new CarDetailsBLL();
            try
            {
                DataTable designationList = bal.GetCarTypeBLL();
                cmbcartype.ItemsSource = designationList.DefaultView;
                cmbcartype.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbcartype.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetTransmission()
        {
            CarDetailsBLL bal = new CarDetailsBLL();
            try
            {
                DataTable designationList = bal.GetCarTransmissionBLL();
                cmbTransType.ItemsSource = designationList.DefaultView;
                cmbTransType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbTransType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetCarsDetails()   //displays service requests
        {
            try
            {
                CarDetailsBLL bal = new CarDetailsBLL();
                List<CarDetailsEntities> cars = bal.GetAllRequestBLL();
                if (cars != null)
                {

                    dgcar.ItemsSource = cars;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (MyCarException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            AddCar();
            GetCars();
        }
        private void AddCar()
        {
            try
            {
                int manufacturerName;

                string model;

                int cartype;

                string engine;

                int bhp;

                int transmission;

                int mileage;

                int seats;

                string airbags;

                string bootSpace;

                string Price;

                //
                bool caradded;
                //
                manufacturerName = Convert.ToInt32(cmbmanfID.SelectedValue);
                model = txtmodel.Text;
                cartype = Convert.ToInt32(cmbcartype.SelectedValue);
                engine = txtEng.Text;
                bhp = Convert.ToInt32(txtBHP.Text);
                transmission = Convert.ToInt32(cmbTransType.SelectedValue);
                mileage = Convert.ToInt32(txtMileage.Text);
                seats = Convert.ToInt32(txtSeats.Text);
                airbags = txtAirbags.Text;
                bootSpace = (txtBootspace.Text);
                Price = (txtPrice.Text);
                //
                CarDetailsEntities car = new CarDetailsEntities
                {
                    ManufacturerId = manufacturerName,
                    Model = model,
                    Type = cartype,
                    Engine = engine,
                    BHP = bhp,
                    Transmission = transmission,
                    Mileage = mileage,
                    Seats = seats,
                    Airbags = airbags,
                    BootSpace = bootSpace,
                    price = Price
                };
                CarDetailsBLL bLL = new CarDetailsBLL();
                caradded= bLL.AddCar(car);
                if (caradded == true)
                {
                    MessageBox.Show("New Car details added successfully.");
                }
                else
                {
                    MessageBox.Show("car details couldn't be added.");
                }
            }
            catch (MyCarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetCars()   //displays service requests
        {
            try
            {
                CarDetailsBLL bLL = new CarDetailsBLL();
                List<CarDetailsEntities> cars = bLL.GetAllRequestBLL();
                if (cars != null)
                {
                    dgcar.ItemsSource = cars;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (MyCarException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
