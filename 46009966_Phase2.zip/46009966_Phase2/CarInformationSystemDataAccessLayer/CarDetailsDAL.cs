﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarInformationSystemEntityLayer;
using CarInformationSystemExceptionlayer;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace CarInformationSystemDataAccessLayer
{
    public class CarDetailsDAL
    {

        public bool AddCarDetails(CarDetailsEntities entities)
        {
            bool addedcar = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].[InsertCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter incidentId = new SqlParameter("@ID", entities.Id);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", entities.ManufacturerId);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", entities.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", entities.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", entities.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", entities.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", entities.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", entities.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", entities.Seats);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBag", entities.Airbags);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", entities.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price",entities.price);

                objCom.Parameters.Add(incidentId);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                objCon.Open();
                objCom.ExecuteNonQuery();
                addedcar = true;
            }
            catch (MyCarException ex)
            {
                throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return addedcar;

        }
        public bool UpdateCarDAL(CarDetailsEntities car)
        {
            bool carUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].[UpdateCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter incidentId = new SqlParameter("@ID", car.Id);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", car.ManufacturerId);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", car.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", car.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", car.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", car.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", car.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", car.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", car.Seats);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBag", car.Airbags);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", car.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", car.price);


                //
                objCon.Open();
                objCom.Parameters.Add(incidentId);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
                objCom.ExecuteNonQuery();
                carUpdated = true;
            }
            catch (MyCarException ex)
            {
                throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carUpdated;

        }



        public bool DeleteCarDAL(string model)
        {
            bool carDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].[DeleteCar]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", model);
                //
                objCom.Parameters.Add(objSqlParam_Model);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                carDeleted = true;
            }
            catch (MyCarException ex)
            {
                throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carDeleted;
        }

        public CarDetailsEntities SearchCarDAL(string model)
        {
            CarDetailsEntities objCar = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].SearchCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", SqlDbType.Int);
                SqlParameter objSqlParam_ManufacturerId = new SqlParameter("@ManufacturerId", SqlDbType.Int);
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", SqlDbType.Int);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", SqlDbType.Int);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", SqlDbType.Int);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", SqlDbType.Int);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", SqlDbType.Int);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBag", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", SqlDbType.VarChar, 50);
                //
                objSqlParam_Id.Direction = ParameterDirection.Output;
                objSqlParam_ManufacturerId.Direction = ParameterDirection.Output;
                objSqlParam_Model.Direction = ParameterDirection.Input;
                objSqlParam_Type.Direction = ParameterDirection.Output;
                objSqlParam_Engine.Direction = ParameterDirection.Output;
                objSqlParam_BHP.Direction = ParameterDirection.Output;
                objSqlParam_Transmission.Direction = ParameterDirection.Output;
                objSqlParam_Mileage.Direction = ParameterDirection.Output;
                objSqlParam_Seats.Direction = ParameterDirection.Output;
                objSqlParam_Airbag.Direction = ParameterDirection.Output;
                objSqlParam_BootSpace.Direction = ParameterDirection.Output;
                objSqlParam_Price.Direction = ParameterDirection.Output;
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_ManufacturerId);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
               
                objSqlParam_Model.Value = model;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objCar = new CarDetailsEntities();
                
                    objCar.Id = Convert.ToInt32(objSqlParam_Id.Value);
                    objCar.ManufacturerId = Convert.ToInt32(objSqlParam_ManufacturerId.Value);
                    objCar.Model = (objSqlParam_Model.Value) as string;
                    objCar.Type = Convert.ToInt32(objSqlParam_Type.Value);
                    objCar.Transmission = Convert.ToInt32(objSqlParam_Transmission.Value);
                    objCar.Mileage = Convert.ToInt32(objSqlParam_Mileage.Value);
                    objCar.BHP = Convert.ToInt32(objSqlParam_BHP.Value);
                    objCar.Engine = (objSqlParam_Engine.Value) as string;
                    objCar.Airbags = (objSqlParam_Airbag.Value) as string;
                    objCar.BootSpace = (objSqlParam_BootSpace.Value) as string;
                    objCar.price = (objSqlParam_Price.Value) as string;
                    objCar.Seats = Convert.ToInt32(objSqlParam_Seats.Value);
                
               
            }
            catch (SqlException  ex)
            {
                 throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCar;
        }

        public DataTable GetManufacturerDAL()
        {
            DataTable manufacturerList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].[GetManufacturer]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                manufacturerList = new DataTable();
                manufacturerList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return manufacturerList;
        }


        public DataTable GetCarTypeDAL()
        {
            DataTable CarTypeList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].[GetCarType]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                CarTypeList = new DataTable();
                CarTypeList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarTypeList;
        }

        public DataTable GetCarTransmissionDAL()
        {
            DataTable CarTransmissionList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009966].[GetTransmission]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                CarTransmissionList = new DataTable();
                CarTransmissionList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new MyCarException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarTransmissionList;
        }


        public List<CarDetailsEntities> GetAllCarDetailsDAL()
        {
            List<CarDetailsEntities> cars = new List<CarDetailsEntities>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("[46009966].[GetAllCars]", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;

                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    CarDetailsEntities car1 = new CarDetailsEntities();
                    car1.Id = Convert.ToInt32(objDR[0]);
                    car1.Model = (objDR[1]) as string;
                    car1.ManufacturerId = Convert.ToInt32(objDR[2]);
                    car1.Type = Convert.ToInt32(objDR[3]);
                    car1.Engine = (objDR[4]) as string;
                    car1.BHP = Convert.ToInt32(objDR[5]);
                    car1.Transmission = Convert.ToInt32(objDR[6]);
                    car1.Mileage = Convert.ToInt32(objDR[7]);
                    car1.Seats = Convert.ToInt32(objDR[8]);
                    car1.Airbags = (objDR[9]) as string;
                    car1.BootSpace = (objDR[10]) as string;
                    car1.price = (objDR[11]) as string;
                    cars.Add(car1);
                }
            }

            catch (SqlException objSqlEx)
            {
                throw new MyCarException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return cars;
        }

        public bool RegistrationSearchDAL(string user, string pass)
        {
            SqlConnection objCon = null;
            bool userSearched = false;
            try
            {
                objCon = new SqlConnection(
                       ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);  //connection with database is established
                SqlCommand objCom = new SqlCommand("[46009966].[usp_SearchRegister]", objCon);   //retrieves data into stored procedure
                objCom.CommandType = CommandType.StoredProcedure;
                objCom.Parameters.AddWithValue("@username", user);
                objCom.Parameters.AddWithValue("@pass", pass);
                objCom.Connection = objCon;
                objCon.Open();

                SqlDataReader reader = objCom.ExecuteReader();
                if (reader.Read())
                {
                    userSearched = true;
                }
                objCon.Close();
            }
            catch (Exception cex)
            {
                throw new MyCarException(cex.Message);
            }
            return userSearched;
        }


       
               
        
    }
}
