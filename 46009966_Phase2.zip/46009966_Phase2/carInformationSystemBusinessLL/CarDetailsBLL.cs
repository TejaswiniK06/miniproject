﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarInformationSystemDataAccessLayer;
using CarInformationSystemEntityLayer;
using CarInformationSystemExceptionlayer;
using System.Data;
using System.Data.SqlClient;

namespace carInformationSystemBusinessLL
{
    public class CarDetailsBLL
    {
        public bool AddCar(CarDetailsEntities car)
        {
            bool CarAdded = false;
            try
            {
                CarDetailsDAL detailsDAL = new CarDetailsDAL();
                CarAdded = detailsDAL.AddCarDetails(car);

            }
            catch (MyCarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarAdded;
        }
        public CarDetailsEntities SearchCarBL(string model)
        {
            CarDetailsEntities objCar = null;
            try
            {
                if (model != string.Empty)
                {
                    CarDetailsDAL carDal = new CarDetailsDAL();
                    objCar = carDal.SearchCarDAL(model);
                }
                else
                {
                    throw new MyCarException("Model not found");
                }
            }
            catch (MyCarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objCar;
        }

        public DataTable GetManufacturerBLL()
        {
            DataTable ManufacturerList;
            try
            {
                CarDetailsDAL carDAL = new CarDetailsDAL();
                ManufacturerList = carDAL.GetManufacturerDAL();
            }
            catch (MyCarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ManufacturerList;
        }

        public DataTable GetCarTypeBLL()
        {
            DataTable CarTypeList;
            try
            {
                CarDetailsDAL carDAL = new CarDetailsDAL();
                CarTypeList = carDAL.GetCarTypeDAL(); ;
            }
            catch (MyCarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTypeList;

        }


        public DataTable GetCarTransmissionBLL()
        {
            DataTable CarTransmissionList;
            try
            {
                CarDetailsDAL carDAL = new CarDetailsDAL();
                CarTransmissionList = carDAL.GetCarTransmissionDAL();
            }
            catch (MyCarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTransmissionList;
        }


        public List<CarDetailsEntities> GetAllRequestBLL()
        {
            List<CarDetailsEntities> carList = null;
            try
            {
                CarDetailsDAL DAL = new CarDetailsDAL();
                carList = DAL.GetAllCarDetailsDAL();   //getallrequest in dal is accessed
            }
            catch (MyCarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carList;
        }

        public  bool RegistrationSearchBL(string user, string password)
        {
            bool userSearched = false;
            try
            {
                CarDetailsDAL dAL = new CarDetailsDAL();
                userSearched = dAL.RegistrationSearchDAL(user, password);
            }
            catch (MyCarException cex)
            {
                throw cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userSearched;
        }

        public bool UpdateCarBL(CarDetailsEntities car)
        {
            bool carUpdated = false;
            try
            {

                {
                    CarDetailsDAL carDal = new CarDetailsDAL();
                    carUpdated = carDal.UpdateCarDAL(car);

                }
            }
            catch (MyCarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carUpdated;
        }

        public bool DeleteCarBL(string model)
        {
            bool carDeleted = false;
            try
            {
                if (model!=null)
                {
                    CarDetailsDAL carDal = new CarDetailsDAL();
                    carDeleted = carDal.DeleteCarDAL(model);
                }
                else
                {
                    throw new MyCarException("Car model should be given");
                }
            }
            catch (MyCarException Cex)
            {
                throw Cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carDeleted;
        }
    }
}

       
         

