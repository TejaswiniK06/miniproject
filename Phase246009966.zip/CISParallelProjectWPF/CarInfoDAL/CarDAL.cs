﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CarInfoEntities;
using CarInfoException;
namespace CarInfoDAL
{
    public class CarDAL
    {

        public bool AddByAdminDal(MainCar mainCar, Manufacturer manufacturer)
        {
            bool addedCar = false;
            SqlConnection connection;
            SqlDataAdapter adap;
            MainCar car = null;
            connection = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("[46009966].usp_InsertAdmin", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Model", mainCar.Model);
                cmd.Parameters.AddWithValue("@Engine", mainCar.Engine);
                cmd.Parameters.AddWithValue("@BHP", mainCar.BHP);
                cmd.Parameters.AddWithValue("@Mileage", mainCar.Mileage);
                cmd.Parameters.AddWithValue("@Seat", mainCar.Seat);
                cmd.Parameters.AddWithValue("@AirBagDetails", mainCar.AirBagDetails);
                cmd.Parameters.AddWithValue("@BootSpace", mainCar.BootSpace);
                cmd.Parameters.AddWithValue("@Price", mainCar.Price);
                cmd.Parameters.AddWithValue("@ManufacturerName", manufacturer.ManufacturerName);
                cmd.Parameters.AddWithValue("@ContactPerson", manufacturer.ContactPerson);
                cmd.Parameters.AddWithValue("@RegisteredOffice", manufacturer.RegisteredOffice);
                cmd.Parameters.AddWithValue("@TypeId", mainCar.TypeId);
                cmd.Parameters.AddWithValue("@TransmissionId", mainCar.TransmissionId);

                cmd.Connection = connection;


                int result = cmd.ExecuteNonQuery();



                if (result > 0)
                    addedCar = true;


            }
            catch (SqlException e)
            {
                throw new CarException(e.Message);
            }
            finally
            {
                connection.Close();
            }

            return addedCar;

        }

        public bool RegistrationSearchDAL(string user, string pass)
        {

            bool isUserSearched = false;
            SqlConnection connection = new SqlConnection(
               ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand cmd = new SqlCommand();



            try
            {
                connection.Open();
                cmd.Connection = connection;
                cmd = new SqlCommand("[46009966].[usp_SearchRegister]", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@username", user);
                cmd.Parameters.AddWithValue("@pass", pass);


                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    isUserSearched = true;
                }

            }
            catch (Exception cex)
            {
                throw new CarException(cex.Message);
            }
            finally
            {
                connection.Close();
            }
            return isUserSearched;
        }


        public bool DeleteDal(string model)
        {
            bool isDeleted = false;
            SqlConnection connection;
            // SqlDataAdapter adap;
            // MainCar car = null;
            connection = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand cmd = new SqlCommand();


            try
            {

                connection.Open();
                cmd.Connection = connection;
                cmd = new SqlCommand("[46009966].usp_deleteAdmin", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Model", model);
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    isDeleted = true;
            }
            catch (SqlException ex)
            {
                throw new CarException(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public bool UpdateByAdminDal(MainCar mainCar, Manufacturer manufacturer)
        {
            bool isUpdated = false;

            SqlConnection connection;
            SqlDataAdapter adap;

            connection = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("[46009966].usp_UpdateAdmin", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Model", mainCar.Model);
                cmd.Parameters.AddWithValue("@Engine", mainCar.Engine);
                cmd.Parameters.AddWithValue("@BHP", mainCar.BHP);
                cmd.Parameters.AddWithValue("@Mileage", mainCar.Mileage);
                cmd.Parameters.AddWithValue("@Seat", mainCar.Seat);
                cmd.Parameters.AddWithValue("@AirBagDetails", mainCar.AirBagDetails);
                cmd.Parameters.AddWithValue("@BootSpace", mainCar.BootSpace);
                cmd.Parameters.AddWithValue("@Price", mainCar.Price);
                cmd.Parameters.AddWithValue("@ManufacturerName", manufacturer.ManufacturerName);
                cmd.Parameters.AddWithValue("@ContactPerson", manufacturer.ContactPerson);
                cmd.Parameters.AddWithValue("@RegisteredOffice", manufacturer.RegisteredOffice);
                cmd.Parameters.AddWithValue("@TypeId", mainCar.TypeId);
                cmd.Parameters.AddWithValue("@TransmissionId", mainCar.TransmissionId);

                cmd.Connection = connection;


                int result = cmd.ExecuteNonQuery();



                if (result > 0)
                    isUpdated = true;


            }
            catch (SqlException e)
            {
                throw new CarException(e.Message);
            }
            finally
            {
                connection.Close();
            }

            return isUpdated;

        }

        public DataTable GetCarTypeTableDal()
        {
            DataTable CarTypeList = null;
            SqlConnection con;
            SqlDataAdapter adap;

            con = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand cmd = new SqlCommand();
            try
            {
                con.Open();
                cmd.CommandText = "[46009966].usp_GetCarTypeTable";
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Connection = con;
                CarTypeList = new DataTable();




                adap = new SqlDataAdapter(cmd);
                adap.Fill(CarTypeList);

            }
            catch (SqlException e)
            {
                throw new CarException(e.Message);
            }
            finally
            {
                con.Close();
            }

            return CarTypeList;

        }


        public DataTable GetCarTransmissionTableDal()
        {

            DataTable CarTransList = null;
            SqlConnection con;
            SqlDataAdapter adap;

            con = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();

            try
            {
                con.Open();
                objCom.CommandText = "[46009966].usp_GetCartransmissionTable";
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Connection = con;
                CarTransList = new DataTable();



                adap = new SqlDataAdapter(objCom);
                adap.Fill(CarTransList);

            }
            catch (SqlException e)
            {
                throw new CarException(e.Message);
            }
            finally
            {
                con.Close();
            }

            return CarTransList;

        }


        public DataTable SearchByAdminDal(string mnfname, string cartype)
        {

            DataTable dtw = new DataTable();
            dtw.Clear();
            SqlConnection objCon;
            SqlDataAdapter adap;
            // MainCar car = null;
            objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {
                objCon.Open();


                objCom.Connection = objCon;
                objCom.CommandText = "[46009966].usp_SearchByTypeAdmin";
                objCom.CommandType = CommandType.StoredProcedure;

                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;

                dtw = new DataTable();

                objCom.Parameters.AddWithValue("@ManufacturerName", mnfname);
                objCom.Parameters.AddWithValue("@CarType", cartype);



                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);



            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            return dtw;


        }


        public DataTable SearchByModelDal(string model)
        {
            DataTable dtw = new DataTable();
            dtw.Clear();
            SqlConnection objCon;
            SqlDataAdapter adap;
            MainCar car = null;
            objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {

                objCon.Open();
                objCom.CommandText = "[46009966].usp_SearchCarDetails";
                objCom.CommandType = CommandType.StoredProcedure;

                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;

                objCom.Connection = objCon;
                dtw = new DataTable();

                objCom.Parameters.AddWithValue("@Model", model);



                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);


            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            return dtw;
        }
        //[46009966].usp_DisplayAll//
        public DataTable DisplayAll()
        {
            DataTable dtw = new DataTable();
            dtw.Clear();
            SqlConnection objCon;
            SqlDataAdapter adap;

            objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {

                objCon.Open();
                objCom.CommandText = "[46009966].usp_DisplayAllData";
                objCom.CommandType = CommandType.StoredProcedure;

                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;

                objCom.Connection = objCon;
                dtw = new DataTable();





                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);


            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);
            }
            return dtw;
        }

        public DataTable DisplayCarTableDAL()
        {
            DataTable dtw = new DataTable();
            dtw.Clear();
            SqlConnection objCon;
            SqlDataAdapter adap;

            objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["myconn"].ConnectionString);
            SqlCommand objCom = new SqlCommand();


            try
            {

                objCon.Open();
                objCom.CommandText = "[46009966].usp_displayCarTable";
                objCom.CommandType = CommandType.StoredProcedure;

                // objCom.Parameters.Add("@Model", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;

                objCom.Connection = objCon;
                dtw = new DataTable();





                adap = new SqlDataAdapter(objCom);
                adap.Fill(dtw);


            }
            catch (SqlException objSqlEx)
            {
                throw new CarException(objSqlEx.Message);


            }
            return dtw;

        }
    }

}