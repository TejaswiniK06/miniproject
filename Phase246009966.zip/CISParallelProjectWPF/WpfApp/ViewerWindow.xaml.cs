﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoException;
using CarInfoEntities;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for ViewerWindow.xaml
    /// </summary>
    public partial class ViewerWindow : Window
    {
        public ViewerWindow()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            Searchmodel();


        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
             Refresh();
        }
        private void Searchmodel()
        {
            DataTable dt = new DataTable();
            dt.Clear();
            try
                {
                    // MainCar car = new MainCar();
                    CarBLL bLL = new CarBLL();
                    string model = (cmbModels.Text);

                    dt = bLL.SearchByModelBLL(model);
                    dg.DataContext = dt;



                }
                catch (CarException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        private void DisplayforViewers()
        {
            DataTable dt = new DataTable();
            dt.Clear();
            CarBLL bLL = new CarBLL();
            dt = bLL.DisplayAllBLL();
            dg.DataContext = dt;
            if (dt.Rows.Count > 0)
            {
                cmbModels.Items.Clear();
                //while (dt.Rows.Count > 0)

                //{
                //    //  dt.Rows[0]["Engine"].ToString();
                for (int x = 0; x < dt.Rows.Count; x++)
                {
                    cmbModels.Items.Add(dt.Rows[x]["Model"].ToString());
                }


            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayforViewers();
        
            }

        private void Refresh()
        {

            cmbModels.Items.Clear();
            cmbModels.Text = " ";
            DisplayforViewers();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
