﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SalesEntities;
using SalesExceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace SalesDAL
{
    public class SDAL
    {

        

        SqlConnection connection = new SqlConnection("server = NDAMSSQL\\SQLILEARN; database=Training_19Sep19_Chennai;Integrated Security = false; user id = sqluser; password=sqluser");
        SqlDataReader sdr=null;
        SqlCommand cmd;
        DataTable dt;
        List<Product> PList = new List<Product>();
        public bool CreatePDAL(Product ent)
        {
            bool PCreated = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_AddProduct";
                cmd.Parameters.AddWithValue("@SerialNumber", ent.SerialNumber);
                cmd.Parameters.AddWithValue("@ProductName", ent.ProductName);
                cmd.Parameters.AddWithValue("@BrandName", ent.BrandName);
                cmd.Parameters.AddWithValue("@ProductType", ent.ProductType);
                cmd.Parameters.AddWithValue("@ProductDescription", ent.ProductDescription);
                cmd.Parameters.AddWithValue("@Price", ent.Price);
                cmd.Connection = connection;

                connection.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                    PCreated = true;
                connection.Close();
            }
            catch (Exception cex)
            {
                throw new SalesException(cex.Message);
            }
            return PCreated;
        }

        public Product SearchProductByID(string SerialNumber)
        {
            try
            {
                //List<Product> prodList = new List<Product>();
                Product p1 = new Product();
                connection.Open();

                cmd = new SqlCommand();
                
                cmd.CommandText = "usp_searchproduct";
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter p;
                p = new SqlParameter("@SerialNumber", SerialNumber);
                cmd.Parameters.Add(p);
                cmd.Connection = connection;

                sdr = cmd.ExecuteReader();
                sdr.Read();
                
                if (sdr!=null)
                {
                   
                        p1.SerialNumber = sdr[0].ToString();
                        p1.ProductName = sdr[1].ToString();
                        p1.BrandName = sdr[2].ToString();
                        p1.ProductType = sdr[3].ToString();
                        p1.ProductDescription = sdr[4].ToString();
                        p1.Price = Single.Parse(sdr[5].ToString());

                }
                connection.Close();
                return p1;
            }
            
            catch(Exception ex)
            {
                throw new SalesException(ex.Message);
            }
        }


        //public bool UpdateProduct(Product product)
        //{
        //    bool updated = false;
        //    try
        //    {
        //        Product p = new Product();

        //        SqlCommand cmdUpdate = new SqlCommand("usp_updateProduct", connection);
        //        cmdUpdate.CommandType = CommandType.StoredProcedure;

        //        SqlParameter p1, p2, p3, p4,p5,p6;
        //        p1 = new SqlParameter("@SerialNumber",product.SerialNumber);
        //        p2 = new SqlParameter("@ProductName",product.ProductName);
        //        p3 = new SqlParameter("@BrandName",p.BrandName);
        //        p4 = new SqlParameter("@ProductDescription",p.ProductDescription);
        //        p6 = new SqlParameter("@Producttype", p.ProductType);
        //        p5 = new SqlParameter("@Price", p.Price);
        //        //p1.SqlDbType = SqlDbType.VarChar;
        //        //p2.SqlDbType = SqlDbType.VarChar;
        //        //p3.SqlDbType = SqlDbType.VarChar;
        //        //p4.SqlDbType = SqlDbType.Float;

        //        p1.Direction = ParameterDirection.Input;
        //        p2.Direction = ParameterDirection.Input;
        //        p3.Direction = ParameterDirection.Input;
        //        p4.Direction = ParameterDirection.Input;
        //        cmdUpdate.Parameters.Add(p1);
        //        cmdUpdate.Parameters.Add(p2);
        //        cmdUpdate.Parameters.Add(p3);
        //        cmdUpdate.Parameters.Add(p4);
        //        cmdUpdate.Parameters.Add(p5);
        //        connection.Open();
        //        cmdUpdate.ExecuteNonQuery();
        //        updated = true;

        //    }
        //    catch (SalesException ex)
        //    {
        //        throw new SalesException(ex.Message);
        //    }

        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }

        //    }


        //}


        public bool UpdateProduct(Product prod)
        {
            bool updated = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UPDATE_Prod";
                cmd.Parameters.AddWithValue("@SerialNumber", prod.SerialNumber);
                cmd.Parameters.AddWithValue("@ProductName", prod.ProductName);
                cmd.Parameters.AddWithValue("@BrandName", prod.BrandName);
                cmd.Parameters.AddWithValue("@ProductType", prod.ProductType);
                cmd.Parameters.AddWithValue("@ProductDescription", prod.ProductDescription);
                cmd.Parameters.AddWithValue("@Price", prod.Price);
                cmd.Connection = connection;
                connection.Open();

                if (cmd.ExecuteNonQuery() > 0)
                    updated = true;

            }
            catch (Exception pex)
            {
                throw new SalesException(pex.Message);
            }
            return updated;
        }



        public bool deleteProductDAL(String SerialNumber)
        {
            try
            {
                connection.Open();
                SqlCommand cmddelete = new SqlCommand("usp_deleteproduct", connection);
                cmddelete.CommandType = CommandType.StoredProcedure;
                SqlParameter p;
                p = new SqlParameter("@SerialNumber", SerialNumber);
                cmddelete.Connection = connection;
                cmddelete.Parameters.Add(p);
                cmddelete.ExecuteNonQuery();
                connection.Close();

                return true;
                 }
            catch (Exception ex)
            {
                throw new SalesException(ex.Message);
            }

            
        }


        public List<Product> DisplayAllDAL()
        {
            List<Product> prodList = new List<Product>();
            try
            {


                cmd = new SqlCommand();
                cmd.CommandText = "usp_Display";
                cmd.CommandType = CommandType.StoredProcedure;

                connection.Open();
                cmd.Connection = connection;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Product p = new Product();

                    //p.SerialNumber = dr[0].ToString();
                    p.SerialNumber = dr.GetString(0);
                    p.ProductName = dr.GetString(1);
                    p.BrandName = dr.GetString(2);
                    p.ProductType = dr.GetString(3);
                    p.ProductDescription = dr.GetString(4);
                    p.Price = float.Parse(dr.GetString(5));

                    prodList.Add(p);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                throw new SalesException(ex.Message);
            }
            return prodList;



        }
    }
}









