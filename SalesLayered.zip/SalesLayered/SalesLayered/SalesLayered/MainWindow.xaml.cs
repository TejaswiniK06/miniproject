﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using SalesBLL;
using SalesEntities;
using SalesExceptions;
using System.Windows.Shapes;

namespace SalesLayered
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Product p1;
        
        public MainWindow()
        {
            InitializeComponent();
            
            //lblpname.Visibility = Visibility.Visible;
            //lblbname.Visibility = Visibility.Visible;
          
            //lblPdis.Visibility = Visibility.Visible;
            //lblpri.Visibility = Visibility.Visible;

            //txtPname.Visibility = Visibility.Visible;
            //txtBname.Visibility = Visibility.Visible;
            //txtpdis.Visibility = Visibility.Visible;
            //txtpri1.Visibility = Visibility.Visible;

        }


        private void BtnAdd_Click_1(object sender, RoutedEventArgs e)
        {
            {
                SubmitRequest();//method to submit the records
                

            }
            //method to add details
            void SubmitRequest()
            {
                try
                {
                    if (txtSnumber.Text.Length > 0 && txtPname.Text.Length > 0 && txtBname.Text.Length > 0 && cmbPtype.Text.Length > 0 && txtpri1.Text.Length > 0)
                    {
                        Product p = new Product();
                        p.SerialNumber = txtSnumber.Text;
                        p.ProductName = txtPname.Text;
                        p.BrandName = txtBname.Text;
                        p.ProductType = ((ComboBoxItem)cmbPtype.SelectedItem).Content.ToString();

                        p.ProductDescription = txtpdis.Text;
                        p.Price = float.Parse(txtpri1.Text);

                        SalesBL SLBL = new SalesBL();

                        bool added = SalesBL.AddProductBLL(p);
                        if (added)
                            MessageBox.Show(" Product added successfully");

                        else
                            MessageBox.Show("Details are not added ");
                    }
                    else
                    {
                        MessageBox.Show("All fields are mandotory");
                    }
                }
                catch (SalesException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }


        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                SalesBL sbl = new SalesBL();
                Product p = null;
                p = SalesBL.SearchProductByIDBLL(txtSnumber.Text);

                if (p != null)
                {
                    cmbPtype.Text = p.ProductType;
                    txtBname.Text = p.BrandName;
                    txtpdis.Text = p.ProductDescription;
                    txtpri1.Text = p.Price.ToString();
                    txtPname.Text = p.ProductName;
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                Product p1 = new Product();
                //if (p1 != null)
                //{
                    p1.SerialNumber = txtSnumber.Text;
                    p1.ProductName = txtPname.Text;
                    p1.BrandName = txtBname.Text;
                    p1.ProductType = cmbPtype.Text;
                    p1.ProductDescription = txtpdis.Text;
                    p1.Price = float.Parse(txtpri1.Text);

                    //SalesBL sbl = new SalesBL();

                    bool updated = SalesBL.UpdateProductBLL(p1);

                    if (updated==true)
                    {
                        MessageBox.Show("Details are updated");
                    }
                    else
                    {
                        MessageBox.Show("Details are not updated");
                    }
                //}
                //else
                //{
                //    MessageBox.Show("ID not found");
                //}

            }
            catch (SalesException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

            try
            {


                String SerialNumber = txtSnumber.Text;
                bool deleted = false;
                deleted = SalesBL.deleteProductBLL(SerialNumber);
                if (deleted)
                {


                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("Not deleted");
                }
            }
            catch (SalesException ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        //private void DiaplayButton()
        //{
        //    try
        //    {

        //        //    SalesBL objProdBL = new SalesBL();
        //        //    List<Product> prodList = objProdBL.DisplayAllBLL(objProdBL.ToString());
        //        //    dggrid.ItemsSource = prodList;

        //        //}

        //        //SalesBL sbl = new SalesBL();
        //        List<Product> ProdList = SalesBL.DisplayAllBLL();
        //        if (ProdList != null)
        //        {
        //            dggrid.ItemsSource = ProdList;
        //        }
        //        else
        //        {
        //            MessageBox.Show("No records available.");
        //        }
        //    }
        //    catch (SalesException ex)
        //    {

        //        MessageBox.Show(ex.Message);
        //    }
        //}\


        private void DisplayProduct()
        {
            try
            {
                List<Product> products = SalesBL.DisplayAllBLL();
                if (products != null)
                {
                    dggrid.ItemsSource = products;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (SalesException pex)
            {

                MessageBox.Show(pex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DisplayProduct();
        }
    }
}

        
    
    





    

