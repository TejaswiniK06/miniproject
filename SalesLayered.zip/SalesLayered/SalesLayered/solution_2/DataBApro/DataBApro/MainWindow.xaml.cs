﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataBApro
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_19Sep19_ChennaiEntities db = null;
        Product p1 = null;
        public MainWindow()
        {
            InitializeComponent();
            db = new Training_19Sep19_ChennaiEntities();
            p1 = new Product();
        }
        //Code to display records
        private void BtnDis_Click(object sender, RoutedEventArgs e)
        {
            {
                var query = from res in db.Products
                            where res.ProductType ==cmbPt.Text
                            select res;
                dggridList.ItemsSource = query.ToList();// giving records to data grid
            }
        }
    }
}
