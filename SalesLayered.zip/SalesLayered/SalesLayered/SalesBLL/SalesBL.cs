﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SalesExceptions;
using SalesEntities;
using System.Text.RegularExpressions;
using SalesDAL;
using System.Threading.Tasks;

namespace SalesBLL
{
    public class SalesBL
    {
       
        
        //public static string Types(string str)
        //{
        //    string validate = String.Empty;
        //    if (Regex.IsMatch(str, @"[0-9]{4}-[0-9]{4}-[0-9]{4}"))
        //        validate = "SerialNumber";

        //    return validate;
        //}

        public static bool Validate(Product p)
        {
            StringBuilder sb = new StringBuilder();
            bool validate = true;
            try
            {
                if (!Regex.IsMatch(p.SerialNumber, @"[0-9]{4}-[0-9]{4}-[0-9]{4}"))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Serial number Format is incorrect.(correct format is :1234-1234-1234)");

                }
                if (p.ProductType != "Mobiles" && p.ProductType != "Camera" && p.ProductType != "Laptop" && p.ProductType != "Appliances" && p.ProductType != "Accessories")
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Designation should be Mobiles,Camera,Laptop,Appliances,Accessories");

                }
                if (p.Price < 0)
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Price should be > 0");
                }
                if (p.SerialNumber == String.Empty || p.ProductName == String.Empty || p.BrandName == String.Empty || p.ProductType == String.Empty || p.ProductDescription == String.Empty || p.Price.ToString() == String.Empty)
                {
                    sb.Append(Environment.NewLine + "All Fields are mandotory");
                }
                if (!validate)
                {
                    throw new SalesException(sb.ToString());
                }

            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validate;
        }
        public static bool AddProductBLL(Product p)
        {
            bool added = false;
            try
            {
                if (Validate(p))
                {
                    SDAL sl = new SDAL();

                    added = sl.CreatePDAL(p);
                }
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }

        public static bool deleteProductBLL(String SerialNumber)
        {
            bool deleted = false;

            try
            {
                SDAL sll = new SDAL();
                deleted = sll.deleteProductDAL(SerialNumber);

            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deleted;
        }


        //public bool UpdateProductBLL(string SerialNumber)
        //{
        //    SDAL sdl = new SDAL();
        //     sdl.UpdateProduct(SerialNumber);
        //}

        public static bool UpdateProductBLL(Product product)
        {
            bool updated = false;
            try
            {
                SDAL sdal = new SDAL();
                updated = sdal.UpdateProduct(product);

            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new SalesException(ex.Message);
            }
            return updated;
        }

        public static Product SearchProductByIDBLL(String Serial)

        {
            Product productsea = null;
            try
            {
                productsea = new Product();
                SDAL sdal = new SDAL();
                productsea = sdal.SearchProductByID(Serial);

            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return productsea;

        }



        public static List<Product> DisplayAllBLL()
        {
            List<Product> productList = new List<Product>();
            try
            {
                SDAL sl = new SDAL();
                productList = sl.DisplayAllDAL();

            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return productList;
        }


    }

}
