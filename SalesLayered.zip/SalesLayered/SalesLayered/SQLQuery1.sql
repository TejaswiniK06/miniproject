use Training_19Sep19_Chennai

create Schema [46008057]
drop table Product
create table Product(
SerialNumber varchar(20) primary key,
ProductName varchar(100) not null,
BrandName varchar(20) not null,
ProductType varchar(20) not null,
ProductDescription varchar(100) not null,
Price varchar(20) not null,
)
select * from Product
drop proc usp_AddProduct
---------------------------------------------------------------------------------------------------------------------------------------------------
create proc usp_AddProduct(

@SerialNumber varchar(20),
@ProductName varchar(100),
@BrandName varchar(100),
@ProductType varchar(20),
@ProductDescription varchar(100),
@Price varchar(20)
)
as 
insert into Product values(@SerialNumber,@ProductName,@BrandName,@ProductType,@ProductDescription,@Price)
go
Exec  usp_AddProduct '1000-1000-1005','iBall Compbook Excelance laptop','iBall','Laptops','Windows 10,11.6 inches Screen','2969.0000'
Exec  usp_AddProduct '1000-1000-1001','iBall Compbook Excelance laptop','iBall','cameras','Windows 10,11.6 inches Screen','2969.0000'
Exec  usp_AddProduct '1000-1000-1007','iBall Compbook Excelance laptop','iBall','Appliances','Windows 10,11.6 inches Screen','2969.0000'
drop proc usp_Display
---------------------------------------------------------------------------------------------------------------
 Create Proc usp_updateProduct
( @SerialNumber varchar(20),
  @ProductName varchar(100),
  @BrandName varchar(100),
  @ProductType VARCHAR(30),
  @ProductDescription varchar(100),
  @Price varchar(20)
 )
AS
BEGIN

UPDATE Product SET ProductName=@ProductName, BrandName=@BrandName,ProductDescription=@ProductDescription,ProductType=@ProductType,Price=@Price WHERE  SerialNumber=@SerialNumber

END
exec usp_updateProduct '1000-1000-1007','GalaxyM40','Samsung','Mobiles','Android 10,11.6 inches Screen','2960'
exec usp_updateProduct 'dell','vivo','Laptops','Android 10,11.6 inches Screen','2969.0000'
exec usp_updateProduct 'dslr','vinni','cameras','10.11.6 inches Screen','2009.0000'

drop proc usp_updateProduct
-----------------------------------------------------------------------------------------------------------------------------------------------------
create proc usp_Display

as 
select * from Product
go
drop proc usp_Display
Exec usp_Display
------------------------------------------------------------------------------------------------------------------------ 
create proc usp_searchproduct

( 
@SerialNumber VARCHAR(20)
)

AS
BEGIN
SELECT * FROM Product WHERE SerialNumber= @SerialNumber
END

exec usp_searchproduct '1000-1000-1005'
exec usp_searchproduct 'cameras'
drop proc usp_searchproduct
--------------------------------------------------------------------------------------------------------------------
---delete----
create proc usp_deleteproduct
( @SerialNumber VARCHAR(30)
)

AS
BEGIN
 delete from Product WHERE SerialNumber=@SerialNumber
 END
 exec usp_deleteproduct '1000-1000-1005'
 exec usp_deleteproduct 'Laptops'
 drop proc usp_deleteproduct