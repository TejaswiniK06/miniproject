﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoBLL;
using CarInfoException;
using CarInfoEntities;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Window
    {
        public AdminPage()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSort_Click(object sender, RoutedEventArgs e)
        {
            Searchmodel();
        }

        private void Btnlogout_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayWPF();
        }
        private void DisplayWPF()
        {
            try
            {
                CarBLL bLL = new CarBLL();
                DataTable dt = bLL.DisplayAllBLL();
                dg.DataContext = dt;
                if (dt.Rows.Count > 0)
                {

                    //while (dt.Rows.Count > 0)

                    //{
                    //    //  dt.Rows[0]["Engine"].ToString();
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        cmbModel.Items.Add(dt.Rows[x]["Model"].ToString());
                    }
                        
                    
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Searchmodel()
        {
            try
            {
                // MainCar car = new MainCar();
                CarBLL bLL = new CarBLL();
                string model = (cmbModel.Text);

                DataTable dt = bLL.SearchByModelBLL(model);
                dg.DataContext = dt;



            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

      
    }
}
